package com.example.health_diary

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
