import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:health_diary/dashboard/dashboard_drawer.dart';
import '../dashboard/dashboard_drawer.dart';
class Dashboard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Dashboard"),
        backgroundColor: Colors.red,
      ),
      drawer: DashboardDrawer(),
      body: ListView(
        padding: EdgeInsets.all(5.0),
        children: [
          Container(
          padding: EdgeInsets.only(top: 30,left: 10,right: 10),
          color: Colors.white,
          child: Column(
            children: [
              Text("Welcome Muhammad Ahmad",style: TextStyle(
                  fontSize: 30,
                  fontWeight: FontWeight.bold
                ),
              ),
              SizedBox(height: 10),
              Container(
                height: 200,
                width: MediaQuery.of(context).size.width,
                child: Card(
                  elevation: 30,
                  color: Colors.red,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(
                            flex:2,
                            child: Container(
                              padding: EdgeInsets.only(left: 10,top: 20),
                              child: Text(
                                "Not a better healthcare, but a better "
                                    "healthcare experience",style: TextStyle(
                                fontSize: 24,
                                color: Colors.white,
                                ),
                              ),
                            ),
                          ),
                          // Expanded(
                          //     child: Image(
                          //       image: AssetImage('assets/images/hp.jpg'),
                          //     ),
                          //   )
                          Expanded(
                            child: Container(
                              padding: EdgeInsets.only(top: 30,right: 20),
                              child: CircleAvatar(
                                  radius: 55,
                                  backgroundImage: AssetImage('assets/images/hp.jpg'),
                                ),
                            ),
                          )
                        ],
                      ),
                      Container(
                        padding: EdgeInsets.only(left: 10),
                        child: FlatButton(
                            onPressed: () {},
                            color: Colors.amberAccent,
                            child: Text("Predict Disease",style: TextStyle(
                              fontSize: 18
                            ),)
                        ),
                      )
                    ],
                  ),
                ),
              ),

            //  Heart Rate Box
              SizedBox(height: 15),
              Container(
                height: 200,
                width: MediaQuery.of(context).size.width,
                child: Card(
                  elevation: 30,
                  color: Colors.red,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(
                            flex:1,
                            child: Container(
                              padding: EdgeInsets.only(left: 10,top: 20),
                              child: Text(
                                "Do your part, "
                                    "care for your heart",style: TextStyle(
                                fontSize: 24,
                                color: Colors.white,
                              ),
                              ),
                            ),
                          ),
                          Expanded(
                            child: Container(
                              padding: EdgeInsets.only(top: 30,left: 35),
                              child: CircleAvatar(
                                radius: 55,
                                backgroundImage: AssetImage('assets/images/hr.jpg'),
                              ),
                            ),
                          )
                        ],
                      ),
                      Container(
                        padding: EdgeInsets.only(left: 10),
                        child: FlatButton(
                            onPressed: () {},
                            color: Colors.amberAccent,
                            child: Text("Monitor Heart Rate",style: TextStyle(
                                fontSize: 18
                            ),)
                        ),
                      )
                    ],
                  ),
                ),
              ),


            //  BMI Box
              SizedBox(height: 15),
              Container(
                height: 200,
                width: MediaQuery.of(context).size.width,
                child: Card(
                  elevation: 30,
                  color: Colors.red,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(
                            flex:1,
                            child: Container(
                              padding: EdgeInsets.only(left: 10,top: 20),
                              child: Text(
                                "Your stomach shouldn’t be a waist basket.",style: TextStyle(
                                fontSize: 24,
                                color: Colors.white,
                              ),
                              ),
                            ),
                          ),
                          Expanded(
                            child: Container(
                              padding: EdgeInsets.only(top: 30,left: 35),
                              child: CircleAvatar(
                                radius: 55,
                                backgroundImage: AssetImage('assets/images/bmi.jpg'),
                              ),
                            ),
                          )
                        ],
                      ),
                      Container(
                        padding: EdgeInsets.only(left: 10),
                        child: FlatButton(
                            onPressed: () {
                              Navigator.of(context).pushNamed('/dashboard/bmi_calculator');
                            },
                            color: Colors.amberAccent,
                            child: Text("Check BMI",style: TextStyle(
                                fontSize: 18
                            ),)
                        ),
                      )
                    ],
                  ),
                ),
              ),


              // Nutrition Box
              SizedBox(height: 15),
              Container(
                height: 200,
                width: MediaQuery.of(context).size.width,
                child: Card(
                  elevation: 30,
                  color: Colors.red,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(
                            flex:1,
                            child: Container(
                              padding: EdgeInsets.only(left: 10,top: 20),
                              child: Text(
                                "For your health’s sake, skip the chips and the cake!",style: TextStyle(
                                fontSize: 24,
                                color: Colors.white,
                              ),
                              ),
                            ),
                          ),
                          Expanded(
                            child: Container(
                              padding: EdgeInsets.only(top: 30,left: 35),
                              child: CircleAvatar(
                                radius: 55,
                                backgroundImage: AssetImage('assets/images/diet.jpg'),
                              ),
                            ),
                          )
                        ],
                      ),
                      Container(
                        padding: EdgeInsets.only(left: 10),
                        child: FlatButton(
                            onPressed: () {},
                            color: Colors.amberAccent,
                            child: Text("Plan Nutrition",style: TextStyle(
                                fontSize: 18
                            ),)
                        ),
                      )
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
        ]
      ),
    );
  }
}